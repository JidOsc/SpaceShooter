﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace SpaceShooter
{
    internal class Label : InterfaceElement
    {
        public string
            text;

        public SpriteFont 
            font;

        public Label(Vector2 position, Vector2 size, string identifier, string text) : base(position, size, identifier)
        {
            this.text = text;
            font = Common.fonts[identifier.Replace("Text", "Font")];
            layer = 0.1f;
            //hämtar font med samma namn som identifier, fast text ersätts av font
        }

        override public void Draw(SpriteBatch _spriteBatch)
        {
            _spriteBatch.DrawString(font, text, position, color, 0, Vector2.Zero, 1, SpriteEffects.None, layer);
        }
    }
}
